<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'zxtfmwrs_zxtfmwrs');
define('DB_PASSWORD', 'ws;0V;5YG2p0Az');
define('DB_NAME', 'zxtfmwrs_mnr_course');

// API Key
define('API_KEY', 'frostfoe1337');

// Establish database connection
$mysqli = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
