<?php
require_once 'session_check.php';
require_once 'config.php';

$message = '';
$error = '';
$api_url = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
        $description = $_POST['description'] ?? '';
        $filename = $_FILES['csv_file']['name'];
        $file_tmp = $_FILES['csv_file']['tmp_name'];
        $file_size = $_FILES['csv_file']['size'];
        $file_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        // Validate file type
        if ($file_ext !== 'csv') {
            $error = 'Invalid file type. Only CSV files are allowed.';
        }
        // Validate file size
        elseif ($file_size > 5 * 1024 * 1024) { // 5MB
            $error = 'File size exceeds 5MB limit.';
        } else {
            // Parse CSV to JSON
            $csv_data = array_map('str_getcsv', file($file_tmp));
            if (count($csv_data) > 0) {
                $headers = array_shift($csv_data);
                $json_array = [];
                foreach ($csv_data as $row) {
                    if (count($headers) == count($row)) {
                        $json_array[] = array_combine($headers, $row);
                    }
                }
                $json_text = json_encode($json_array, JSON_PRETTY_PRINT);
                $row_count = count($json_array);
                $size_kb = round($file_size / 1024, 2);

                // Store in database
                $stmt = $mysqli->prepare("INSERT INTO csv_files (filename, description, json_text, row_count, size_kb) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssid", $filename, $description, $json_text, $row_count, $size_kb);

                if ($stmt->execute()) {
                    $last_id = $stmt->insert_id;
                    $message = 'File uploaded and processed successfully!';
                    $domain = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'];
                    $api_url = "{$domain}/api/get.php?id={$last_id}&key=" . API_KEY;
                } else {
                    $error = 'Database error: ' . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = 'CSV file is empty or invalid.';
            }
        }
    } else {
        $error = 'No file uploaded or an error occurred during upload.';
    }
    $mysqli->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload CSV</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Admin Dashboard</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
        <h2>Upload CSV File</h2>
        <?php if ($message): ?>
            <div class="alert alert-success">
                <?php echo $message; ?>
                <hr>
                <p>API Scrape URL:</p>
                <div class="input-group mb-3">
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($api_url); ?>" id="apiUrl">
                    <button class="btn btn-outline-secondary" type="button" id="copyButton">Copy URL</button>
                </div>
                <a href="index.php" class="btn btn-primary">View Dashboard</a>
            </div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="csv_file" class="form-label">CSV File</label>
                <input class="form-control" type="file" id="csv_file" name="csv_file" accept=".csv" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Upload</button>
        </form>
    </div>
    <script>
        if (document.getElementById('copyButton')) {
            document.getElementById('copyButton').addEventListener('click', function() {
                var copyText = document.getElementById('apiUrl');
                copyText.select();
                copyText.setSelectionRange(0, 99999); // For mobile devices
                document.execCommand('copy');
                alert('Copied the URL: ' + copyText.value);
            });
        }
    </script>
</body>
</html>
